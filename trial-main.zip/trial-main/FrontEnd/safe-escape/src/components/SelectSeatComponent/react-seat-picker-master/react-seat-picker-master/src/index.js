import "./styles/index.scss";
import { SeatPicker } from "./SeatPicker/SeatPicker";

export default SeatPicker;
