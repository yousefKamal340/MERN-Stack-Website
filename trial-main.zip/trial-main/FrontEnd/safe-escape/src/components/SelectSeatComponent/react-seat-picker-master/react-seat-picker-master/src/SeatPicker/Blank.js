import React, { Component } from "react";

export default class Blank extends Component {
  render() {
    return <div className="blank" />;
  }
}
