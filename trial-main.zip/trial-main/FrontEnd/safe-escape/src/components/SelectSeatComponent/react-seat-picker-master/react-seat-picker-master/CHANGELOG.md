## [1.5.3](https://github.com/roggervalf/react-seat-picker/compare/v1.5.2...v1.5.3) (2020-04-13)


### Bug Fixes

* merge pull request [#12](https://github.com/roggervalf/react-seat-picker/issues/12) ([d2fdcba](https://github.com/roggervalf/react-seat-picker/commit/d2fdcba5fbfb19daabfa7482927b2d5b313435b0))
* merge pull request [#13](https://github.com/roggervalf/react-seat-picker/issues/13) ([768f48b](https://github.com/roggervalf/react-seat-picker/commit/768f48b59fafa1ccd0fe0d06afe0c938a238e9fe))
