// const express = require('express');
// const { models } = require('mongoose');
// const UserController = require('../Controller/UserController');
// const UserRouter = express.Router();
// UserController.use(express.json());
// UserController.use(express.urlencoded({ extended: false }));

// UserRouter.get('/getUsers', UserController.getUsers);

// module.exports = UserRouter;